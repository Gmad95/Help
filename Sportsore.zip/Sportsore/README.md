# Configurare una Web App su Azure

* Creare un gruppo di risorse su Azure
* Creare un progetto su Visual Studio
* Click destro sul progetto e selezionare publish
* Nella finestra che si aprira' selezionare il gruppo di risorse che si vuole utilizzare
* Dopo che l'app e' stata caricata, all'interno del gruppo di risorse selezionare tale app
* Nel menu' che comparira' sulla sinistra selezionare la voce Deployment slots e creare un nuovo slot
* Fatto cio' sara' possibile effettuare uno swap con la Web Application che e' stata creata, cio' significa che tutte le modifiche possono essere scambiate tra la Web App e lo Slot, in modo da avere varie zone di lavoro, molto simile ai branch in git

## Stringa di connessione in .NetCore, inserire la ConnectionStrings in appsettings.Development.json

```json
"ConnectionStrings": {
    "BloggingDatabase": "Server=(localdb)\\mssqllocaldb;Database=EFGetStarted.ConsoleApp.NewDb;Trusted_Connection=True;"
  },
```

## Link utili

* [Configurazione Asp.net Core](https://docs.microsoft.com/it-it/aspnet/core/fundamentals/configuration/index?view=aspnetcore-2.2)
* [Application Insights](https://docs.microsoft.com/it-it/azure/azure-monitor/app/app-insights-overview#how-do-i-use-application-insights)
* [Depedency Injection in ASP.NET Core](https://docs.microsoft.com/it-it/aspnet/core/fundamentals/dependency-injection?view=aspnetcore-2.2)
* [Getting Started with ASP.NET Core](https://docs.microsoft.com/it-it/aspnet/core/getting-started/?view=aspnetcore-2.2&tabs=windows)
* [MVC Schema](https://docs.microsoft.com/it-it/aspnet/core/mvc/overview?view=aspnetcore-2.2)
* [Razor Pages](https://docs.microsoft.com/it-it/aspnet/core/razor-pages/?view=aspnetcore-2.2&tabs=visual-studio)
* [Alternative If statement - Conditional Operator](https://docs.microsoft.com/en-us/dotnet/csharp/language-reference/operators/conditional-operator)
* [Operatore Lambda](https://docs.microsoft.com/it-it/dotnet/csharp/language-reference/operators/lambda-operator)
* [Punto interrogativo dopo una variabile - Null Conditional Operator](https://stackoverflow.com/questions/28352072/what-does-question-mark-and-dot-operator-mean-in-c-sharp-6-0?answertab=votes#tab-top)
* [Linq](https://docs.microsoft.com/it-it/dotnet/csharp/programming-guide/concepts/linq/introduction-to-linq-queries)
* [Binding in ASP.NET Core](https://docs.microsoft.com/en-us/aspnet/core/mvc/models/model-binding?view=aspnetcore-2.2)
* [Start a test](https://docs.microsoft.com/it-it/visualstudio/test/getting-started-with-unit-testing?view=vs-2017)
* [Get started with xUnit and Moq](https://www.codeproject.com/Articles/1168172/Get-Started-with-Unit-Testing-using-xUnit-and-Moq)
* [xUnit](https://docs.microsoft.com/it-it/dotnet/core/testing/unit-testing-with-dotnet-test)
* [Convertire la stringa in oggetto json](https://stackoverflow.com/questions/22870624/convert-json-string-to-json-object-c-sharp)
* [Mock quickstart](https://github.com/Moq/moq4/wiki/Quickstart)
* [Introduzione ai Logs](https://logmatic.io/blog/logging-in-net-the-power-of-c-logs/)
* [AddSingleton](https://docs.microsoft.com/en-us/dotnet/api/microsoft.extensions.dependencyinjection.servicecollectionserviceextensions.addsingleton?view=aspnetcore-2.2)
* [Replace document fails](https://stackoverflow.com/questions/29725561/documentdb-replacedocument-fails?answertab=votes#tab-top)
* [CreateDocumentUri](https://docs.microsoft.com/en-us/dotnet/api/microsoft.azure.documents.client.urifactory.createdocumenturi?view=azure-dotnet)
* [Get started with CosmosDB](https://docs.microsoft.com/en-us/azure/cosmos-db/sql-api-dotnetcore-get-started)
* [Replace Document Uri](https://docs.microsoft.com/en-us/dotnet/api/microsoft.azure.documents.client.documentclient.replacedocumentasync?view=azure-dotnet)
* [Increase performance](https://www.c-sharpcorner.com/UploadFile/dacca2/5-tips-to-improve-performance-of-C-Sharp-code/)
* [Youtube dl](https://rg3.github.io/youtube-dl/)
* [Dependency injection](https://docs.microsoft.com/it-it/aspnet/core/fundamentals/dependency-injection?view=aspnetcore-2.2)
* [Create an exe](https://stackoverflow.com/questions/44074121/build-net-core-console-application-to-output-an-exe)
* [Kubernetes](https://kubernetes.io/)
* [ASP.net Core Github Exercises](https://github.com/Apress/pro-asp.net-core-mvc-2)
* [Boostnote](https://boostnote.io/)
* [Angular and Asp.net](https://www.amazon.it/Essential-Angular-ASP-NET-Core-MVC/dp/1484229150)
* [SPA(single page application) with Asp.net](https://docs.microsoft.com/en-us/aspnet/web-api/overview/getting-started-with-aspnet-web-api/build-a-single-page-application-spa-with-aspnet-web-api-and-angularjs)
* [MVVM and MVC differences](https://stackoverflow.com/questions/667781/what-is-the-difference-between-mvc-and-mvvm)
* [Data Structures](http://www.vcskicks.com/csharp_data_structures.php)
* [Formatting output](https://docs.microsoft.com/en-us/dotnet/csharp/language-reference/keywords/formatting-numeric-results-table)
* [Yield keyword](https://stackoverflow.com/questions/39476/what-is-the-yield-keyword-used-for-in-c)
* [Delegate](https://docs.microsoft.com/it-it/dotnet/csharp/language-reference/keywords/delegate)
* [Pass method as param (delegate)](https://stackoverflow.com/questions/2082615/pass-method-as-parameter-using-c-sharp)
* [Nameof](https://docs.microsoft.com/en-us/dotnet/csharp/language-reference/keywords/nameof)
* [ViewBag](https://stackoverflow.com/questions/14896013/how-viewbag-in-asp-net-mvc-works)
* [Getting Started with Bower](https://jakeydocs.readthedocs.io/en/latest/client-side/bower.html)
* [Use bootstrap with Asp.net Core](https://www.bootstrapdash.com/asp-net-core-with-bootstrap-4/)
* [Solid Wikipedia](https://en.wikipedia.org/wiki/SOLID)
* [Solid principles](https://blogs.msdn.microsoft.com/cdndevs/2009/07/15/the-solid-principles-explained-with-motivational-posters/)
* [Examples and definitions of the SOLID principles in Software Design](https://blog.scottlogic.com/2018/06/26/solid-principles.html)
* [ASP.Net Core Middleware](https://docs.microsoft.com/en-us/aspnet/core/fundamentals/middleware/?view=aspnetcore-2.2)
* [Tag helper](https://docs.microsoft.com/en-us/aspnet/core/mvc/views/tag-helpers/intro?view=aspnetcore-2.2)
* [MapRoute](https://docs.microsoft.com/en-us/aspnet/core/fundamentals/routing?view=aspnetcore-2.2)
* [Tag Helpers Razor Pages](https://www.learnrazorpages.com/razor-pages/tag-helpers)
* [Create a helper tag in ASP.Net Core](https://docs.microsoft.com/it-it/aspnet/core/mvc/views/tag-helpers/authoring?view=aspnetcore-2.2)
* [Asp.net Core Tag Helpers (TutorialsPoint)](https://www.tutorialspoint.com/asp.net_core/asp.net_core_razor_tag_helpers.htm)
* [Asp.net Core create 404 Page](https://gooroo.io/GoorooThink/Article/17086/Creating-Custom-Error-Pages-in-ASPNET-core-10/32407)
* [Middleware](https://www.tutorialspoint.com/asp.net_core/asp.net_core_middleware.htm)

## Alternativa ad accesso ftp

Usare il site control manager chiamato Kudu, per trovare file, error log, viariabili d'ambiente ecc.
Per poter accedere bisogna prima avere la Web App Avviata e poi nell'url, subito dopo il nome del sito, bisogna digitare .scm 

## Shortcut keys

```
ctrl k c commenta dopo aver selezionato
ctrl  u decommenta dopo aver selezionato
ctrl k f formatta dopo aver selezionato
ctrl . opzioni rapide
ctrl - torna indietro
ctrl shift s salva tutto
ctrl shift b compila
f12 contenuto selezionato rimanda al metodo
ctrl r r contenuto selezionato renaming e refactoring
"ctor" tab tab crea il costruttore
ctrl F5 fai partire il programma in realise
```

## Creazione del sito ProductsStore, riferimento capitolo 8

### Creazione del progetto MVC

1. Creare un progetto vuoto in Asp.Net core lato web
2. Specificare progetto vuoto
3. Creare le seguenti cartelle: **Models, Views, Controllers**
4. Nel file **Startup.cs** bisogna modificare la classe **Startup** per fare in modo che vengano abilitate delle funzionalita' utili per lo sviluppo

```cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
namespace SportsStore {
  public class Startup {
    public void ConfigureServices(IServiceCollection services) {
      services.AddMvc();
    }
    public void Configure(IApplicationBuilder app, IHostingEnvironment env) {
        app.UseDeveloperExceptionPage();
        app.UseStatusCodePages();
        app.UseStaticFiles();
        app.UseMvc(routes => {

        });
    }
  }
}
```

**services.AddMvc()** abilita ASP.Net Core MVC.
**app.UseStaticFiles()** permette di utilizzare i file che sono contenuti in una cartella, se non viene specifato un **percorso(path)**, viene utilizzato quello di default, che sarebbe **wwwroot**.
**app.UseStatusCodePages()** aggiunge un semplice messaggio ad una richiesta HTTP che non dispone di un body, per esempio se si dovesse verificare un errore 404 verra' visualizzato il seguente messaggio: **404 - Not Found**.
**app.UseDeveloperExceptionPage()** se si verificano delle **eccezioni**, tramite questo metodo verranno visualizzate in una pagina **HTML**. Deve essere utilizzato solo in fase di sviluppo.
Il metodo **Configure**, viene usato per impostare le caratteristiche (features) che ricevono e processano le **richieste HTTP**, ogni metodo che viene chiamato nel **Configure** e' l'estensione di un metodo che processa and imposta una **richiesta HTTP**.

4. Creare un file _ViewImports.cshtml nella cartella **Views** con il seguente contenuto: 

```cs
@using SportsStore.Models
@addTagHelper *, Microsoft.AspNetCore.Mvc.TagHelpers
```

La keyword **@using** permette di utilizzare **SportsStore.Models** namespace in views senza bisogno di fare riferimento a tale namespace.

### Creare il Domain Model

5. Creare in models un file **Product.cs** con il seguente contenuto:

```cs
namespace SportsStore.Models {
  public class Product {
    public int ProductID { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
    public decimal Price { get; set; }
    public string Category { get; set; }
  }
}
```

6. Definire un'**interfaccia** per gestire la persistenza dei dati, invece nel **model Product** includo la logica per memorizzare e recuperare i dati da uno store di dati persistente. Creare un file **IProductRepository.cs** in Models con il seguente contenuto:

```cs
using System.Linq;
namespace SportsStore.Models {
  public interface IProductRepository {
    IQueryable<Product> Products { get; }
  }
}
```

Questa interfaccia utilizza **IQueryable<T>** per permettere al chiamante di ottenere una sequenza di oggetti di tipo **Product**. L'interfaccia **IQueryable<T>** e' derivata dall'interfaccia **IEnumarable<T>** e rappresenta una collezione di oggetti su cui posso effettuare delle **query**, come se fosse un database. Una classe che dipende dall'interfaccia **IProductRepository** puo' ottenere oggetti di tipo **Product** senza il bisogno di conoscere i dettagli di come sono memorizzati o senza conoscere come l'impletazione della classe gestisce tali dettagli.

7. Creare un file **FakeProductRepository.cs** nella cartella **Models** con il seguente contenuto:


```cs
using System.Collections.Generic;
using System.Linq;
namespace SportsStore.Models {
  public class FakeProductRepository : IProductRepository {
    public IQueryable<Product> Products => new List<Product> {
      new Product { Name = "Football", Price = 25 },
      new Product { Name = "Surf board", Price = 179 },
      new Product { Name = "Running shoes", Price = 95 }
      }.AsQueryable<Product>();
    }
}
```

La classe **FakeProductRepository** implementa **IProductRepository** ritornando una collezione di oggetti **Product** come valori della **property Products**. Il metodo **AsQueryable** e' usato per convertire la collezione di oggetti in **IQuerable<Product>** che e' richiesta per implementare l'interfaccia **IProductRepository** e mi permette di creare fake repository compatibile senza bisogno di aver a che fare con query reali.

8. Aggiornare il file **Startup.cs** con il seguente contenuto:

```cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using SportsStore.Models;
namespace SportsStore {
  public class Startup {
    public void ConfigureServices(IServiceCollection services) {
      services.AddTransient<IProductRepository, FakeProductRepository>();
      services.AddMvc();
    }
    public void Configure(IApplicationBuilder app, IHostingEnvironment env) {
      app.UseDeveloperExceptionPage();
      app.UseStatusCodePages();
      app.UseStaticFiles();
      app.UseMvc(routes => {

      });
    }
  }
}
```

MVC enfatizza l'utilizzo di  _loosely coupled components_, che significa che possono essere fatte delle modifiche in una parte della applicazione senza bisogno di dover fare delle modifiche da un'altra parte. Questo processo categorizza le parti dell'applicazione in _servizi_ (services) che mette a disposizione delle **features** in altre parti per l'utilizzo dell'applicazione.
Il metodo **AddTransient** specifica un nuovo oggetto **FakeProductRepository** che dovrebbe essere creato ogni volta che l'interfaccia **IProductRepository** ne ha bisogno.

### Visualizzare una lista di Products

9. Creare **ProductController.cs** in **Controllers** per poter visualizzare i dettagli dei dati, il file ha il seguente contenuto: 

```cs
using Microsoft.AspNetCore.Mvc;
using SportsStore.Models;
namespace SportsStore.Controllers {
  public class ProductController : Controller {
    private IProductRepository repository;
    public ProductController(IProductRepository repo) {
      repository = repo;
    }
  }
}
```

Quando MVC ha bisogno di creare una nuova istanza della **classe ProductController** per gestire la richiesta HTTP, controllera' il costruttore in modo da vedere che richiede un'implementazione dell'oggetto dell'interfaccia **IProductRepository**. Per determinare la classe che dovra' essere utilizzata, MVC controllera' la configurazione nella classe **Startup**, che dice di utilizzare **FakeRepository** e di ogni volta di creare una sua istanza. Quindi MVC crea un nuovo oggetto **FakeRepository** e lo usa per invocare il costruttore di **ProductController** in modo da creare un oggetto controller che processera' la richiesta HTTP.
Questo meccanismo e' chiamato _Dependency Injection_ che permette al costruttore **ProductController** di accedere al repository dell'applicazione attraverso **IProductRepository** senza bisogno di sapere quale impletenzione di una classe e' stata utilizzata.

10. Aggiungere un metodo Action in nel file **ProductController.cs**:

```cs
using Microsoft.AspNetCore.Mvc;
using SportsStore.Models;
namespace SportsStore.Controllers {
  public class ProductController : Controller {
    private IProductRepository repository;
    public ProductController(IProductRepository repo) {
      repository = repo;
    }
    public ViewResult List() => View(repository.Products);
  }
}
```

Chiamare un metodo **View** in questo modo(senza specificare un nome per la View) dice ad MVC di renderizzare la view di default con il metodo action.

11. Creare in Views/Shared il file _Layout.cshtml con il seguente contenuto:

```html
<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width" />
    <title>SportsStore</title>
  </head>
  <body>
    <div>
    @RenderBody()
    </div>
  </body>
</html>
```

12. Creare in Views il file _ViewStart.cshtml con il seguente contenuto:

```cs
@{
  Layout = "_Layout";
}
```

12. Creare una cartella Views/Product con dentro il file List.cshtml con il seguente contenuto:

```cs
@model IEnumerable<Product>
@foreach (var p in Model) {
  <div>
    <h3>@p.Name</h3>
    @p.Description
    <h4>@p.Price.ToString("c")</h4>
  </div>
}
``` 
L'espressione @model all'inizio specifica che la vista riceverà una sequenza dell'oggetto prodotto dall'action method, viene usato un foreach per generare dell'html per visualizzare gli oggetti che vengono ricevuti
La vista non sa da dove arriva l'oggetto Product ne come sono stati ottenuti. La vista si occupa solo di come i dettagli di ogni prodotto devono essere visualizzati tramite l'html
Con il tostring() ATTENZIONE ALLA CULTURE SELEZIONATA, POTREBBE VARIARE LA VISUALIZZAZIONE DEL NUMERO

13. Cambiare la route di default in Startup.cs con il seguente contenuto: 

```cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using SportsStore.Models;

namespace SportsStore {
  public class Startup {
    public void ConfigureServices(IServiceCollection services) {
      services.AddTransient<IProductRepository, FakeProductRepository>();
      services.AddMvc();
    }
    public void Configure(IApplicationBuilder app, IHostingEnvironment env) {
      app.UseDeveloperExceptionPage();
      app.UseStatusCodePages();
      app.UseStaticFiles();
      app.UseMvc(routes => {
        routes.MapRoute(
        name: "default",
        template: "{controller=Product}/{action=List}/{id?}");
      });
    }
  }
}
```
Setto la route di default a per puntare alla metodo List della classe ProductController.

**UseMvc** imposta il MVC middleware, e una delle opzioni di configurazione e' lo schema che sara' usato per mappare gli URLs dei controllers e i metodi action. In sostanza MVC manda le richieste al metodo **List** action di **Product** controller.

### Preparare il database
Attualmente l'applicativo utilizza un database fake, ora bisogna settare il database per mandare dei dati veri. Verrà utilizzato L'Entity Framework core (EF core) che l'object-relational mapping (ORM) del framework.

14. Aprire esplora risorse andare nella cartella del proprio progetto, aprire il SportsStore.csproj e aggiornare il contenuto, procedere con il salvataggio, per poter scaricare il pacchetto **Microsoft.EntityFrameworkCore.Tools.DotNet**:

```xml
  <Project Sdk="Microsoft.NET.Sdk.Web">
    <PropertyGroup>
      <TargetFramework>netcoreapp2.0</TargetFramework>
    </PropertyGroup>
    <ItemGroup>
      <Folder Include="wwwroot\" />
    </ItemGroup>
    <ItemGroup>
      <PackageReference Include="Microsoft.AspNetCore.All" Version="2.0.0" />
      <DotNetCliToolReference Include="Microsoft.EntityFrameworkCore.Tools.DotNet" Version="2.0.0" />
    </ItemGroup>
  </Project>
```

15. Creare in Models il file ApplicationDbContext.cs con il seguente contenuto:

```cs
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.DependencyInjection;
namespace SportsStore.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options) { }
        public DbSet<Product> Products { get; set; }
    }

    public class ApplicationDbContextFactory
            : IDesignTimeDbContextFactory<ApplicationDbContext> {

        public ApplicationDbContext CreateDbContext(string[] args) =>
            Program.BuildWebHost(args).Services
                .GetRequiredService<ApplicationDbContext>();
    }//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
}
```

La classe base **DbContext** permette l'accesso alle funzionalita' dell' Entity Framework, e la proprieta' **Products** permettera' l'accesso agli oggetti di tipo **Product** nel database.

16. Creare un file EFProductRepository.cs in Models, in modo da poter implementare l'interfaccia IProductRepository ed ottenere i suoi dati usando l'Entity Framework:

```cs
using System.Collections.Generic;
using System.Linq;
namespace SportsStore.Models {
  public class EFProductRepository : IProductRepository {
    private ApplicationDbContext context;
    public EFProductRepository(ApplicationDbContext ctx) {
      context = ctx;
    }
    public IQueryable<Product> Products => context.Products;
  }
}
```
Attualmemte l'implementazione della repository sta mappando le proprietà di Product definiti nell'omonima interfaccia nelle proprietà definite dalla classe ApplicationDbContext. Le porprietà di Products ritorneranno un oggetto DbSet<Product> che implementea IQueryable<T>, questo permettte alle query di ritornare solo gli oggetti che sono necessari. 


###Definire la  Connection String 

17. Creare un file appsettings.json nella directory principale:
!!ATTENZIONE!! Vuisual studio incolla male il json, potrebbero esserci errori durante la compilazione se non si controlla che la stringa di connessione sia ben formata. 
```json
{
  "Data": {
    "SportStoreProducts": {
      "ConnectionString": "Server=(localdb)\\MSSQLLocalDB;Database=SportsStore;Trusted_Connection=True;MultipleActiveResultSets=true"
    }
  }
}
```
A questo punto bisogna leggere la connstring e configurare l'applicativo per connettersi al db
18. Aggiornare il file Startup.cs: 

```cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using SportsStore.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore;
namespace SportsStore {
  public class Startup {
    public Startup(IConfiguration configuration) =>
    Configuration = configuration;
    public IConfiguration Configuration { get; }
    public void ConfigureServices(IServiceCollection services) {
      services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(Configuration["Data:SportStoreProducts:ConnectionString"]));
      services.AddTransient<IProductRepository, EFProductRepository>();
      services.AddMvc();
    }
    public void Configure(IApplicationBuilder app, IHostingEnvironment env) {
      app.UseDeveloperExceptionPage();
      app.UseStatusCodePages();
      app.UseStaticFiles();
      app.UseMvc(routes => {
        routes.MapRoute(
          name: "default",
          template: "{controller=Product}/{action=List}/{id?}");
      });
    }
  }
}
```
Il costruttore aggiunto alla classe riceve i dati di configurazione dal file json e li inserisce in una proprietà, così che potranno essere utilizzati nel resto della classe.

L'estensione AddDbContext del metodo imposta i servizi dell'EF core. L'argomento del metodo è una lambda exp che riceve un'opzione che configura il db. In questo caso il db è stato confugurato per essere sqlserver, questa configurazione arriva dal file di configurazione appsettings.json
In questo caso è stato anche sostituito il fake repository con uno vero.
Grazie alla dependency injection viene iniettata la nuova interfaccia senza dover cambiare la classe ProductController.

18b. Cambiare il file Program.cs:

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SportsStore;

```cs
namespace SportStore
{
    public class Program 
    {
        public static void Main(string[] args)
        {
            BuildWebHost(args).Run();
        }

        public static IWebHost BuildWebHost(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>()
                .UseDefaultServiceProvider(options =>
                    options.ValidateScopes = false)
                .Build();
    }
}
```

19. Creare le migration utilizzando la command line, posizionandosi nella cartella del progetto:

```powershell
dotnet ef migrations add Initial

package manager console:

Add-Migration Initial

Update-Database
```
Se ci sono problemi è meglio controllare quanti file .csproj ci sono ed eliminare quelli in eccesso

20. Creare un file SeedData.cs in Models per popolare il database:

```cs
using System.Linq;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
namespace SportsStore.Models {
  public static class SeedData {
    public static void EnsurePopulated(IApplicationBuilder app) {
      ApplicationDbContext context = app.ApplicationServices.GetRequiredService<ApplicationDbContext>();
      context.Database.Migrate();
      if (!context.Products.Any()) {
        context.Products.AddRange(
          new Product {
            Name = "Kayak", Description = "A boat for one person",
            Category = "Watersports", Price = 275 
          },
          new Product {
            Name = "Lifejacket",
            Description = "Protective and fashionable",
            Category = "Watersports", Price = 48.95m
          },
          new Product {
            Name = "Soccer Ball",
            Description = "FIFA-approved size and weight",
            Category = "Soccer", Price = 19.50m 
          },
          new Product {
            Name = "Corner Flags",
            Description = "Give your playing field a professional touch",
            Category = "Soccer", Price = 34.95m 
          },
          new Product {
            Name = "Stadium",
            Description = "Flat-packed 35,000-seat stadium",
            Category = "Soccer", Price = 79500 
          },
          new Product {
            Name = "Thinking Cap",
            Description = "Improve brain efficiency by 75%",
            Category = "Chess", Price = 16 
          },
          new Product {
            Name = "Unsteady Chair",
            Description = "Secretly give your opponent a disadvantage",
            Category = "Chess", Price = 29.95m 
          },
          new Product {
            Name = "Human Chess Board",
            Description = "A fun game for the family",
            Category = "Chess", Price = 75 
          },
          new Product {
            Name = "Bling-Bling King",
            Description = "Gold-plated, diamond-studded King",
            Category = "Chess", Price = 1200
          }
        );
        context.SaveChanges();
      }
    }
  }
}
```

**EnsurePopulated** sara' richiamato in seguito all'interno del metodo Configure nel file **Startup.cs**, riceve come parametro un IApplicationBuilder che rappresenta l'interfaccia usata in **Configure** per registrare i componenti middleware per gestire le chiamate HTTP. EnsurePopulated ottiene un oggetto **ApplicationDbContext** attraverso **IApplicationBuilder** e chiama il **Database.Migrate** per assicurarsi che la migration sia stata applicata, in altre parole significa che il database verra' creato e sara' pronto per memorizzare oggetti di tipo **Product**. In seguito vengono controllati tali oggetti e se non sono presenti nel database allora tale database verra' popolato usando la Collection di oggetti di Product e usando il metodo AddRange, infine verranno scritte le modifiche sul database usando il metodo SaveChanges.

21. Aggiornare Startup.cs:

```cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using SportsStore.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore;
namespace SportsStore {
  public class Startup {
    public Startup(IConfiguration configuration) => Configuration = configuration;
    public IConfiguration Configuration { get; }
    public void ConfigureServices(IServiceCollection services) {
      services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(Configuration["Data:SportStoreProducts:ConnectionString"])); //!!!
      services.AddTransient<IProductRepository, EFProductRepository>(); //!!
      services.AddMvc();
    }
    public void Configure(IApplicationBuilder app, IHostingEnvironment env) {
      app.UseDeveloperExceptionPage();
      app.UseStatusCodePages();
      app.UseStaticFiles();
      app.UseMvc(routes => {
        routes.MapRoute(
        name: "default",
        template: "{controller=Product}/{action=List}/{id?}");
      });
      SeedData.EnsurePopulated(app);
    }
  }
}
```
Facendo partire l'applicazione il DB verrà creato e riempito dei con i dati di seed.
Quando il browser richiede l'url di default, la configurazione dell'applicazione dice al MVC che bisogna creare un'istanza di Product, creando una nuova istanza di ProductController. 

Se ci sono problemi nella creazione da due classi diverse, cancellare fisicamente i file dalla cartella
Migration e rieseguire dotnet ef migrations add Initial


### Preparare la paginazione 
22. Aggiungere al file ProductController 

```cs
using Microsoft.AspNetCore.Mvc;
using SportsStore.Models;
using System.Linq;
namespace SportsStore.Controllers
{
    public class ProductController : Controller
    {
        private IProductRepository repository;
        public int PageSize = 4;
        public ProductController(IProductRepository repo)
        {
            repository = repo;
        }
        public ViewResult List(int productPage = 1)
        => View(repository.Products
        .OrderBy(p => p.ProductID)
        .Skip((productPage - 1) * PageSize)
        .Take(PageSize));
    }
}
```
Il campo PageSize specifica che voglio 4 elementi per pagina. Ho aggiunto un parametro opzionale al metodo List.

### Visualizzare il link delle pagine
Attualmente per passare da una pagina all'altra devo passare in query string il parametro corretto:
Es: http://localhost:5000/?productPage=2
Per aggiungere i numeri delle pagine:

Per supportare il TagHelper, andrò a passare informazioni alla vista sul numero di pagine disponibili, e il numero totale di prodotti nella rep. Il  modo più facile per fare questo è di creare una classe view model che passa questi dati tra vista e controller.

23. Creare la cartella Models/ViewModels e aggiungere il file PagingInfo.cs con il seguente contenuto:

```cs
using System;
namespace SportsStore.Models.ViewModels
{
    public class PagingInfo
    {
        public int TotalItems { get; set; }
        public int ItemsPerPage { get; set; }
        public int CurrentPage { get; set; }
        public int TotalPages =>
        (int)Math.Ceiling((decimal)TotalItems / ItemsPerPage);
    }
}
```

Creare una cartella infrastructure.

24. Aggiungere la classe Tag Helper. Aggiungere un file  PageLinkTagHelper.cs alla cartella infrastruttura con il seguente contenuto:

```cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;
using SportsStore.Models.ViewModels;
namespace SportsStore.Infrastructure
{
    [HtmlTargetElement("div", Attributes = "page-model")]
    public class PageLinkTagHelper : TagHelper
    {
        private IUrlHelperFactory urlHelperFactory;
        public PageLinkTagHelper(IUrlHelperFactory helperFactory)
        {
            urlHelperFactory = helperFactory;
        }
        [ViewContext]
        [HtmlAttributeNotBound]
        public ViewContext ViewContext { get; set; }
        public PagingInfo PageModel { get; set; }
        public string PageAction { get; set; }
        public override void Process(TagHelperContext context,
        TagHelperOutput output)
        {
            IUrlHelper urlHelper = urlHelperFactory.GetUrlHelper(ViewContext);
            TagBuilder result = new TagBuilder("div");
            for (int i = 1; i <= PageModel.TotalPages; i++)
            {
                TagBuilder tag = new TagBuilder("a");
                tag.Attributes["href"] = urlHelper.Action(PageAction,
                new { productPage = i });
                tag.InnerHtml.Append(i.ToString());
                result.InnerHtml.AppendHtml(tag);
            }
            output.Content.AppendHtml(result.InnerHtml);
        }
    }
}
```

Il Tag Helper popola un elemento div con gli elementi corrispondenti ai prodotti. I Tag Helpers sono il modo più semplice per inserire logica in C# nelle viste.

25. I Tag Helpers vanno registrati, quindi in _ViewImports.cshtml aggiornare il file:

```cs
@using SportsStore.Models
@using SportsStore.Models.ViewModels
@addTagHelper *, Microsoft.AspNetCore.Mvc.TagHelpers
@addTagHelper SportsStore.Infrastructure.*, SportsStore
```

Aggiungere i dati nel view model

Non sono ancora pronto a usare i Tag Helpers perché non ho ancora fornito un istanza della vista PagingInfo alla vista. Potrei utilizzare la view bag, ma metterò tutti i dati che ho intenzione di mandare dal controller alla vista in una singola view model. Per fare questo:

26. Aggiungo un file ProductsListViewModel nella cartella Models/ViewModels con il seguente contenuto.

```cs
using System.Collections.Generic;
using SportsStore.Models;
namespace SportsStore.Models.ViewModels
{
    public class ProductsListViewModel
    {
        public IEnumerable<Product> Products { get; set; }
        public PagingInfo PagingInfo { get; set; }
    }
}
```

27. Aggiorno il metodo List in ProductController:

```cs
using Microsoft.AspNetCore.Mvc;
using SportsStore.Models;
using System.Linq;
using SportsStore.Models.ViewModels;
namespace SportsStore.Controllers
{
    public class ProductController : Controller
    {
        private IProductRepository repository;
        public int PageSize = 4;
        public ProductController(IProductRepository repo)
        {
            repository = repo;
        }
        public ViewResult List(int productPage = 1)
        => View(new ProductsListViewModel
        {
            Products = repository.Products
        .OrderBy(p => p.ProductID)
        .Skip((productPage - 1) * PageSize)
        .Take(PageSize),
            PagingInfo = new PagingInfo
            {
                CurrentPage = productPage,
                ItemsPerPage = PageSize,
                TotalItems = repository.Products.Count()
            }
        });
    }
}
```

Questi cambiamenti passano un oggetto di tipo ProductsListViewModel come modello di dati alla vista.

28. Aggiornare il file List.cshtml:

```cs
@model ProductsListViewModel
@foreach (var p in Model.Products) {
<div>
<h3>@p.Name</h3>
@p.Description
<h4>@p.Price.ToString("c")</h4>
</div>
}
```

Ho cambiato la direttiva di @model per dire a razor che sto lavorando con un data type differente.

Visualizzare i link delle pagine

E' tutto pronto, bisogna aggiungere un elemento html che il Tag Helper possa processare per creare i link delle pagine:

29. Aggiungere la paginazione quindi aggiornare List.cshtml:

```cs
@model ProductsListViewModel
@foreach (var p in Model.Products)
{
    <div>
        <h3>@p.Name</h3>
        @p.Description
        <h4>@p.Price.ToString("c")</h4>
    </div>
}
<div page-model="@Model.PagingInfo" page-action="List"></div>
```


Aggiungere lo stile al contenuto (bootstrap)













